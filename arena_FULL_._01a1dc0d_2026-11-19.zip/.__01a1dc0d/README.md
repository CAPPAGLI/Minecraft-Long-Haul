# Я ищу сборку для майнкрафт. Я знаю, что есть множество модов, которые позволяют… — Arena Full Export

ID: 01a1dc0d-d4a4-7d3e-af7d-d84d5258d78f
Type: agentic
Data source: merged:dom(54)+network:fetch-response(20)+network:fetch-response(20)+api:/api/chat/01a1dc0d-d4a4-7d3e-af7d-d84d5258d78f(20)+api:/api/chat/01a1dc0d-d4a4-7d3e-af7d-d84d5258d78f(20)+api:/api/chat/01a1dc0d-d4a4-7d3e-af7d-d84d5258d78f(20)+api:/api/chat/01a1dc0d-d4a4-7d3e-af7d-d84d5258d78f(20)+network:fetch-response(2)+network:fetch-response(2)+rsc(6)+rsc(6)+html-flight(6)
Exported: 20.11.2026, 06:15:36
URL: https://arena.ai/agent/01a1dc0d-d4a4-7d3e-af7d-d84d5258d78f
