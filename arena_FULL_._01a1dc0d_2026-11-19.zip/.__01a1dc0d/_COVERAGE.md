# Coverage report

- Type: **agentic**
- Source: `merged:dom(54)+network:fetch-response(20)+network:fetch-response(20)+api:/api/chat/01a1dc0d-d4a4-7d3e-af7d-d84d5258d78f(20)+api:/api/chat/01a1dc0d-d4a4-7d3e-af7d-d84d5258d78f(20)+api:/api/chat/01a1dc0d-d4a4-7d3e-af7d-d84d5258d78f(20)+api:/api/chat/01a1dc0d-d4a4-7d3e-af7d-d84d5258d78f(20)+network:fetch-response(2)+network:fetch-response(2)+rsc(6)+rsc(6)+html-flight(6)`
- Messages: **82**
- User messages: 27
- Assistant messages: 55
- Reasoning parts: 240
- Tool parts: 386
- Empty messages: 0
- Total text: 283524 chars
- Deep load (прокрутка/подгрузка): no
- Первое сообщение от: user

## ⚠️ Warnings

- После первого сообщения пользователя нет ответа ассистента.
- Данные склеены из нескольких источников — проверь _SUMMARY в мердже.


